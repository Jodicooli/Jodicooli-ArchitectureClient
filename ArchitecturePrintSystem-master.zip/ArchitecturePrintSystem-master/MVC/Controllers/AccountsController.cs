﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using MVC.Services;
using DTO;

namespace MVC.Controllers
{
    public class AccountsController : Controller
    {
        private readonly ILogger<AccountsController> _logger;
        private readonly IAccountService _accountService;
        private readonly IPageCostsService _pageCostsService;

        public AccountsController(ILogger<AccountsController> logger, IAccountService accountService, IPageCostsService pageCostsService)
        {
            _logger = logger;
            _accountService = accountService;
            _pageCostsService = pageCostsService;
        }

        public async Task<IActionResult> Index()
        {
            return View(await _accountService.GetAccounts());
        }

        public async Task<IActionResult> Details(int id)
        {
            var account = await _accountService.GetAccount(id);
            return View(account);
        }

        public async Task<IActionResult> CreateAsync()
        {
            ViewBag.Groups = new SelectList(await _accountService.GetGroups(), "GID", "Name");
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(AccountM account)
        {
            
            ViewBag.Groups = new SelectList(await _accountService.GetGroups(), "GID", "Name", account.GroupId);
            AccountM accountM = await _accountService.AddAccount(account);
            if(accountM == null)
            {
                ModelState.AddModelError("Username", "Username already exists");
                return View(account);
            }
            return RedirectToAction(nameof(Index));

        }

        public async Task<IActionResult> Edit(int id)
        {
            var account = await _accountService.GetAccount(id);
            ViewBag.Groups = new SelectList(await _accountService.GetGroups(), "GID", "Name", account.GroupId);
            return View(account);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(AccountM account)
        {
            await _accountService.UpdateAccount(account);
            return RedirectToAction(nameof(Index));
        }


        public async Task<IActionResult> Delete(int id)
        {
            var account = await _accountService.GetAccount(id);
            return View(account);
        }

        [HttpPost, ActionName("Delete")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            await _accountService.DeleteAccount(id);
            return RedirectToAction(nameof(Index));
        }

        //--------------------------------------------------------------------------------
        public IActionResult AddAmount()
        {
            return View(new AdjustBalanceM { SelectedIdentifierType = "Username" }); 
        }

        [HttpPost]
        public async Task<IActionResult> AddAmountByUID(AdjustBalanceM model)
        {
            model.Username = await _accountService.GetUsernameByUID(model.UID.Value);
            if (model.Username == null)
            {
                ModelState.AddModelError("UID", "UID not found");
                model.SelectedIdentifierType = "UID"; 
                return View("AddAmount", model);
            }

            model.CurrentBalance = await _accountService.GetBalanceByUsername(model.Username);
            if (!ModelState.IsValid)
            {
                model.SelectedIdentifierType = "UID";
                return View("AddAmount", model);
            }
            return View("AddAmountConfirm", model);
        }

        [HttpPost]
        public async Task<IActionResult> AddAmountByUsername(AdjustBalanceM model)
        {
            model.UID = await _accountService.GetUIDByUsername(model.Username);
            if (model.UID == null)
            {
                ModelState.AddModelError("Username", "Username not found");
                model.SelectedIdentifierType = "Username"; 
                return View("AddAmount", model);
            }

            model.CurrentBalance = await _accountService.GetBalanceByUsername(model.Username);
            if (!ModelState.IsValid)
            {
                model.SelectedIdentifierType = "Username";
                return View("AddAmount", model);
            }
            return View("AddAmountConfirm", model);
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmAddAmount(AdjustBalanceM model)
        {
            await _accountService.AddAmount(model);
            return RedirectToAction("DisplayAccountDetails", new { username = model.Username });
        }


        public async Task<IActionResult> Print()
        {
            var pageFormats = await _pageCostsService.GetPageCosts();
            var selectList = pageFormats.Select(p => new SelectListItem { Value = p.ID.ToString(), Text = p.PageFormat }).ToList();
            ViewBag.PageFormats = selectList;
            return View(new PrintM { SelectedIdentifierType = "CardID" });
        }

        [HttpPost]
        public async Task<IActionResult> PrintByUsername(PrintM model)
        {
            var selectedPageFormat = await _pageCostsService.GetPageCost(model.Id.Value, model.Quantity);
            model.PageFormat = selectedPageFormat.PageFormat;
            model.UID = await _accountService.GetUIDByUsername(model.Username);
            model.Price = (float)Math.Round(selectedPageFormat.CostOnePage, 2);

            if (model.UID == null)
            {
                ModelState.AddModelError("Username", "Username not found");
                var pageFormats = await _pageCostsService.GetPageCosts();
                var selectList = pageFormats.Select(p => new SelectListItem { Value = p.ID.ToString(), Text = p.PageFormat }).ToList();
                ViewBag.PageFormats = selectList;
                model.SelectedIdentifierType = "Username"; 
                return View("Print", model);
            }
            if (!ModelState.IsValid)
            {
                var pageFormats = await _pageCostsService.GetPageCosts();
                var selectList = pageFormats.Select(p => new SelectListItem { Value = p.ID.ToString(), Text = p.PageFormat }).ToList();
                ViewBag.PageFormats = selectList;
                model.SelectedIdentifierType = "Username";
                return View("Print", model);
            }
            return View("PrintConfirm", model);
        }

        [HttpPost]
        public async Task<IActionResult> PrintByCardId(PrintM model)
        {
            var selectedPageFormat = await _pageCostsService.GetPageCost(model.Id.Value, model.Quantity);
            model.PageFormat = selectedPageFormat.PageFormat;
            model.UID = await _accountService.GetUIDByCardID(model.CardID.Value);
            model.Price = selectedPageFormat.CostOnePage;

            if (model.UID == null)
            {
                ModelState.AddModelError("CardID", "CardID not found");
                var pageFormats = await _pageCostsService.GetPageCosts();
                var selectList = pageFormats.Select(p => new SelectListItem { Value = p.ID.ToString(), Text = p.PageFormat }).ToList();
                ViewBag.PageFormats = selectList;
                model.SelectedIdentifierType = "CardID"; 
                return View("Print", model);
            }
            if (!ModelState.IsValid)
            {
                var pageFormats = await _pageCostsService.GetPageCosts();
                var selectList = pageFormats.Select(p => new SelectListItem { Value = p.ID.ToString(), Text = p.PageFormat }).ToList();
                ViewBag.PageFormats = selectList;
                model.SelectedIdentifierType = "CardID";
                return View("Print", model);
            }
            return View("PrintConfirm", model);
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmPrint(PrintM model)
        {
            var updatedAccount = await _accountService.Print(model);
            if (updatedAccount == null)
            {
                ModelState.AddModelError("balance", "Insufficient balance");
                return View("InsufficientBalance");
            }
            return View("Printing");
        }

        public IActionResult AccountDetails()
        {
            return View();
        }

        public async Task<IActionResult> DisplayAccountDetails(string username)
        {
            var account = await _accountService.GetAccountByUsername(username);
            if (account == null)
            {
                ModelState.AddModelError("Username", "Username not found");
                return View("AccountDetails");
            }
            return View(account);
        }



        public async Task<IActionResult> DetailsUsername(string username)
        {
            var account = await _accountService.GetAccountByUsername(username);
            return View(account);
        }

        public async Task<IActionResult> GroupAsync()
        {
            ViewBag.Groups = new SelectList(await _accountService.GetGroups(), "GID", "Name");
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> AddAmountByGID(AdjustBalanceM adjustBalanceM)
        {
            if (!ModelState.IsValid)
            {
                ViewBag.Groups = new SelectList(await _accountService.GetGroups(), "GID", "Name");
                return View("Group");
            }
            adjustBalanceM = await _accountService.AddAmountByGID(adjustBalanceM);
            return RedirectToAction(nameof(Index));
        }

    }
}
