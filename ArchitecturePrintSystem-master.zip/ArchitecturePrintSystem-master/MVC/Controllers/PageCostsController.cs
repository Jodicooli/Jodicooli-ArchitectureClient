﻿using Microsoft.AspNetCore.Mvc;
using DTO;
using MVC.Services;

namespace MVC.Controllers
{
    public class PageCostsController : Controller
    {
        private readonly ILogger<PageCostsController> _logger;
        private readonly IPageCostsService _pagesCostService;

        public PageCostsController(ILogger<PageCostsController> logger, IPageCostsService pagesCostService)
        {
            _logger = logger;
            _pagesCostService = pagesCostService;
        }

        public async Task<IActionResult> Index()
        {
            return View(await _pagesCostService.GetPageCosts());
        }

        public IActionResult Create()
        {
            return View();
        }

        //create the page cost
        [HttpPost]
        public async Task<IActionResult> Create([Bind("ID,CostOnePage,PageFormat")] PageCostM pageCost)
        {
            if (!ModelState.IsValid)
            {
                return View(pageCost);
            }
            await _pagesCostService.AddPageCost(pageCost);
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Edit(int id)
        {
            if (!ModelState.IsValid)
            {
                return View(id);
            }
            var pageCost = await _pagesCostService.GetPageCost(id);
            return View(pageCost);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(int id, [Bind("ID,CostOnePage,PageFormat")] PageCostM pageCost)
        {
            await _pagesCostService.PutPageCost(pageCost);
            return RedirectToAction(nameof(Index));
        }


        public async Task<IActionResult> Details(int id)
        {
            var pageCost = await _pagesCostService.GetPageCost(id);
            return View(pageCost);
        }

        public async Task<IActionResult> Delete(int id)
        {
            var pageCost = await _pagesCostService.GetPageCost(id);
            return View(pageCost);
        }

        [HttpPost, ActionName("Delete")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var pageCost = await _pagesCostService.DeletePageCost(id);
            return RedirectToAction(nameof(Index));
        }

    }
}
