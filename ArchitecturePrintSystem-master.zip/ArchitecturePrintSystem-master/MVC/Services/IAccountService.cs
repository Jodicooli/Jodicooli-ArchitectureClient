﻿using DTO;

namespace MVC.Services
{
    public interface IAccountService
    {
        Task<IEnumerable<AccountM>> GetAccounts();
        Task<AccountM> GetAccount(int id);
        Task<AccountM> AddAccount(AccountM account);
        Task<AccountM> UpdateAccount(AccountM account);
        Task DeleteAccount(int id);
        Task<IEnumerable<GroupM>> GetGroups();
        Task<AccountM> GetAccountByUsername(string username);
        Task<UserM> GetAccountByCardID(int cardID);
        Task<AccountM> AddAmount(AdjustBalanceM model);
        Task<AccountM> Print(PrintM model);
        Task<int?> GetUIDByUsername(string username);
        Task<int?> GetUIDByCardID(int cardID);
        Task<string?> GetUsernameByUID(int UID);
        Task<float> GetBalanceByUsername(string username);
        Task<AdjustBalanceM> AddAmountByGID(AdjustBalanceM model);

    }
}
