﻿using DTO;

namespace MVC.Services
{
    public class PageCostsService : IPageCostsService
    {

        private readonly HttpClient _client;
        private readonly string _baseUrl;

        public PageCostsService(HttpClient client, IConfiguration configuration)
        {
            _client = client;
            _baseUrl = configuration["WebAPI:BaseUrl"] + "/pagecosts";
        }

        public async Task<PageCostM> AddPageCost(PageCostM pageCost)
        {
            var response = await _client.PostAsJsonAsync(_baseUrl, pageCost);
            if (!response.IsSuccessStatusCode) return null;
            var newPageCost = await response.Content.ReadFromJsonAsync<PageCostM>();
            return newPageCost;
        }

        public async Task<Boolean> DeletePageCost(int id)
        {
            var response = await _client.DeleteAsync($"{_baseUrl}/{id}");
            if (response.IsSuccessStatusCode) return true;
            return false;
        }

        public async Task<List<PageCostM>> GetPageCosts()
        {
            var response = await _client.GetAsync(_baseUrl);
            if (!response.IsSuccessStatusCode) return null;
            var pagecosts = await response.Content.ReadFromJsonAsync<List<PageCostM>>();
            return pagecosts;
        }

        public async Task<PageCostM> GetPageCost(int id)
        {
            var response = await _client.GetAsync($"{_baseUrl}/{id}");
            if (!response.IsSuccessStatusCode) return null;
            var pagecost = await response.Content.ReadFromJsonAsync<PageCostM>();
            return pagecost;
        }

        public async Task<PageCostM> GetPageCost(int id, int quantity)
        {
            var response = await _client.GetAsync($"{_baseUrl}/{id}/{quantity}");
            if (!response.IsSuccessStatusCode) return null;
            var pagecost = await response.Content.ReadFromJsonAsync<PageCostM>();
            return pagecost;
        }

        public async Task<PageCostM> PutPageCost(PageCostM pageCost)
        {
            var response = await _client.PutAsJsonAsync($"{_baseUrl}/{pageCost.ID}", pageCost);
            if (!response.IsSuccessStatusCode) return null;
            var updatedPageCost = await response.Content.ReadFromJsonAsync<PageCostM>();
            return updatedPageCost;
        }

        public async Task<PageCostM> GetPageCostByFormat(string format)
        {
            var response = await _client.GetAsync($"{_baseUrl}/byformat/{format}");
            if (!response.IsSuccessStatusCode) return null;
            var pagecost = await response.Content.ReadFromJsonAsync<PageCostM>();
            return pagecost;
        }

      

    }
}