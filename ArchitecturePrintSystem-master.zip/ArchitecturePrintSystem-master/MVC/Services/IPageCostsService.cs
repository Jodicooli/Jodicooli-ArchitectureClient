﻿using DTO;

namespace MVC.Services
{
    public interface IPageCostsService
    {
        public Task<List<PageCostM>> GetPageCosts();
        public Task<PageCostM> GetPageCost(int id);
        public Task<PageCostM> GetPageCost(int id, int quantity);
        public Task<PageCostM> AddPageCost(PageCostM pageCost);
        public Task<PageCostM> PutPageCost(PageCostM pageCost);
        public Task<Boolean> DeletePageCost(int id);
        Task<PageCostM> GetPageCostByFormat(string format);
        
    }
}