﻿using DTO;

namespace MVC.Services
{
    public class AccountService : IAccountService
    {
        private readonly HttpClient _client;
        private readonly string _baseUrl;

        public AccountService(HttpClient client, IConfiguration configuration)
        {
            _client = client;
            _baseUrl = configuration["WebAPI:BaseUrl"] + "/accounts";
        }

        public async Task<IEnumerable<AccountM>> GetAccounts()
        {
            var response = await _client.GetAsync(_baseUrl);
            response.EnsureSuccessStatusCode();

            var accounts = await response.Content.ReadFromJsonAsync<IEnumerable<AccountM>>();
            return accounts;

        }

        public async Task<AccountM> GetAccount(int id)
        {
            var response = await _client.GetAsync($"{_baseUrl}/{id}");
            if (!response.IsSuccessStatusCode) return null;

            var account = await response.Content.ReadFromJsonAsync<AccountM>();
            return account;

        }

        public async Task<AccountM> AddAccount(AccountM account)
        {
            var response = await _client.PostAsJsonAsync(_baseUrl, account);
            if (!response.IsSuccessStatusCode) return null;
            var newAccount = await response.Content.ReadFromJsonAsync<AccountM>();
            return newAccount;
            
        }

        public async Task<AccountM> UpdateAccount(AccountM account)
        {
            var response = await _client.PutAsJsonAsync($"{_baseUrl}/{account.UID}", account);
            if (!response.IsSuccessStatusCode) return null;
            var updatedAccount = await response.Content.ReadFromJsonAsync<AccountM>();
            return updatedAccount;
        }

        public async Task DeleteAccount(int id)
        {
            var response = await _client.DeleteAsync($"{_baseUrl}/{id}");
            response.EnsureSuccessStatusCode();
        }

        public async Task<IEnumerable<GroupM>> GetGroups()
        {
            var response = await _client.GetAsync(_baseUrl.Replace("accounts", "groups"));
            response.EnsureSuccessStatusCode();
            var groups = await response.Content.ReadFromJsonAsync<IEnumerable<GroupM>>();
            return groups;

        }

        public async Task<AccountM> GetAccountByUsername(string username)
        {
            var response = await _client.GetAsync($"{_baseUrl}/byusername/{username}");
            if (!response.IsSuccessStatusCode) return null;
            var account = await response.Content.ReadFromJsonAsync<AccountM>();
            return account;
        }

        public async Task<UserM> GetAccountByCardID(int cardID)
        {
            var response = await _client.GetAsync(_baseUrl.Replace("accounts", "users") + $"/{cardID}");
            if (!response.IsSuccessStatusCode) return null;
            var account = await response.Content.ReadFromJsonAsync<UserM>();
            return account;
        }

        public async Task<AccountM> AddAmount(AdjustBalanceM model)
        {
            var response = await _client.PutAsJsonAsync(_baseUrl + $"/{model.UID}/AddAmount", model);
            if (!response.IsSuccessStatusCode) return null;
            var account = await response.Content.ReadFromJsonAsync<AccountM>();
            return account;
        }

        public async Task<AccountM> Print(PrintM model)
        {
            var response = await _client.PostAsJsonAsync($"{_baseUrl}/{model.UID}/Print", model);
            if (!response.IsSuccessStatusCode) return null;

            var updatedAccount = await response.Content.ReadFromJsonAsync<AccountM>();
            return updatedAccount;
        }

        public async Task<String?> GetUsernameByUID(int uid)
        {
            var account = await GetAccount(uid);
            if (account == null) return null;
            return account.Username;
        }
   
        public async Task<int?> GetUIDByUsername(string username)
        {
            var account = await GetAccountByUsername(username);
            if (account == null) return null;
            return account.UID;
        }

        public async Task<int?> GetUIDByCardID(int cardID)
        {
            var user = await GetAccountByCardID(cardID);
            if (user == null) return null;
            return user.UID;
        }

        public async Task<float> GetBalanceByUsername(string username)
        {
            var account = await GetAccountByUsername(username);
            return account.Balance;
        }

        public async Task<AdjustBalanceM> AddAmountByGID(AdjustBalanceM accountM)
        {
            var response = await _client.PutAsJsonAsync(_baseUrl + $"/{accountM.SelectedGroupId}/AddAmountByGID", accountM);
            if (!response.IsSuccessStatusCode) return null;
            var newAccount = await response.Content.ReadFromJsonAsync<AdjustBalanceM>();
            return newAccount;
        }
    }
}
