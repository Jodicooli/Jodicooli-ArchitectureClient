﻿using DAL.Models;
using Microsoft.EntityFrameworkCore;

namespace DAL
{
    public class Context : DbContext
    {
        public DbSet<Account> Accounts { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<Group> Groups { get; set; }
        public DbSet<PageCost> PageCosts { get; set; }

        public Context(DbContextOptions<Context> options) : base(options)
        {
        }

        public Context()
        {
        }

        protected override void OnConfiguring(DbContextOptionsBuilder builder)
        {
            //builder.UseSqlServer(@"Server=(localdb)\mssqllocaldb;Database=PrintSystemDB");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Configure the relationship between Group and Account
            modelBuilder.Entity<Group>()
                .HasMany(g => g.Accounts)
                .WithOne(a => a.Group)
                .HasForeignKey(a => a.GroupId);
            
        }
    }
}
