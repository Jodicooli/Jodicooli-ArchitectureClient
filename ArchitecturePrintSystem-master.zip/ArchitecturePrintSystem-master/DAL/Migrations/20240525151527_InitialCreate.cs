﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace DAL.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Groups",
                columns: table => new
                {
                    GID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Groups", x => x.GID);
                });

            migrationBuilder.CreateTable(
                name: "PageCosts",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CostOnePage = table.Column<float>(type: "real", nullable: false),
                    PageFormat = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PageCosts", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "Users",
                columns: table => new
                {
                    UID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CardID = table.Column<int>(type: "int", nullable: false),
                    Username = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Users", x => x.UID);
                });

            migrationBuilder.CreateTable(
                name: "Accounts",
                columns: table => new
                {
                    UID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Lastname = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Surname = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Username = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Balance = table.Column<float>(type: "real", nullable: false),
                    History = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    GroupId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Accounts", x => x.UID);
                    table.ForeignKey(
                        name: "FK_Accounts_Groups_GroupId",
                        column: x => x.GroupId,
                        principalTable: "Groups",
                        principalColumn: "GID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Groups",
                columns: new[] { "GID", "Description", "Name" },
                values: new object[,]
                {
                    { 1, "Business IT 4. Semester french", "604_F" },
                    { 2, "Business IT 4. Semester german", "604_D" },
                    { 3, "Teachers from the HES-SO", "Teacher" }
                });

            migrationBuilder.InsertData(
                table: "PageCosts",
                columns: new[] { "ID", "CostOnePage", "PageFormat" },
                values: new object[,]
                {
                    { 1, 0.08f, "A4bw" },
                    { 2, 0.12f, "A4color" },
                    { 3, 0.12f, "A3bw" },
                    { 4, 0.2f, "A3color" }
                });

            migrationBuilder.InsertData(
                table: "Users",
                columns: new[] { "UID", "CardID", "Username" },
                values: new object[,]
                {
                    { 1, 333, "ral" },
                    { 2, 666, "dia" },
                    { 3, 999, "glg" },
                    { 4, 1332, "suj" },
                    { 5, 1665, "lon" },
                    { 6, 1998, "jat" },
                    { 7, 2331, "wad" },
                    { 8, 2664, "dua" },
                    { 9, 2997, "wia" },
                    { 10, 3330, "scr" }
                });

            migrationBuilder.InsertData(
                table: "Accounts",
                columns: new[] { "UID", "Balance", "GroupId", "History", "Lastname", "Surname", "Username" },
                values: new object[,]
                {
                    { 1, 50f, 1, "[50]", "Ramirez", "Luana", "ral" },
                    { 2, 50f, 1, "[50]", "Dias", "Adriano", "dia" },
                    { 3, 50f, 1, "[50]", "Gloor", "Gian-Luca", "glg" },
                    { 4, 50f, 2, "[50]", "Summermatter", "Johanna", "suj" },
                    { 5, 50f, 2, "[50]", "Lotscher", "Nadja", "lon" },
                    { 6, 50f, 2, "[50]", "Januzi", "Tringa", "jat" },
                    { 7, 100f, 3, "[100]", "Wannier", "David", "wad" },
                    { 8, 100f, 3, "[100]", "Duc", "Alain", "dua" },
                    { 9, 100f, 3, "[100]", "Widmer", "Antoine", "wia" },
                    { 10, 100f, 3, "[100]", "Schumann", "Rene", "scr" }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Accounts_GroupId",
                table: "Accounts",
                column: "GroupId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Accounts");

            migrationBuilder.DropTable(
                name: "PageCosts");

            migrationBuilder.DropTable(
                name: "Users");

            migrationBuilder.DropTable(
                name: "Groups");
        }
    }
}
