﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace DAL.Models
{
    public class Group
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int GID { get; set; }
        public required string Name { get; set; }
        public required string Description { get; set; }
        public ICollection<Account> Accounts { get; } = new List<Account>();
    }
}
