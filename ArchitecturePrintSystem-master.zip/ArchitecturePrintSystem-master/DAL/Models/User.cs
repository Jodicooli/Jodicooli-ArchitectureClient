﻿using System.ComponentModel.DataAnnotations;

namespace DAL.Models
{
    public class User
    {
        [Key]
        public int UID { get; set; }
        public int CardID { get; set; }
        public required string Username { get; set; }
    }
}
