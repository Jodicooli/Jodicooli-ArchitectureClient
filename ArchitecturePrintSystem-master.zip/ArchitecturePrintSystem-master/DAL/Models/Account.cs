﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace DAL.Models
{
    public class Account
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int UID { get; set; }
        public required string Lastname { get; set; }
        public required string Surname { get; set; }
        public required string Username { get; set; }
        public required float Balance { get; set; }
        public List<float>? History { get; set; } = new List<float>();
        public int GroupId { get; set; }
        public Group? Group { get; set; }
    }
}
