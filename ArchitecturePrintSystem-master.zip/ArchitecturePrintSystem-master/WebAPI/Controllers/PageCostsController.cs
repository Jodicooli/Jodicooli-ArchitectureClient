﻿using Microsoft.AspNetCore.Mvc;
using DTO;
using BLL.Services;
using DAL;
using BLL.Mapper;
using Microsoft.EntityFrameworkCore;


namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PageCostsController : ControllerBase
    {
        private readonly IPrintSystem_Service _printSystemService;
        private readonly Context _context;

        public PageCostsController(IPrintSystem_Service printSystemService, Context context)
        {
            _printSystemService = printSystemService;
            _context = context;
        }

        // GET: api/PageCosts
        [HttpGet]
        public async Task<ActionResult<IEnumerable<PageCostM>>> GetPageCosts()
        {
            var pageCosts = await _printSystemService.GetConversion();
            return Ok(pageCosts);
        }

        // GET: api/PageCosts/5
        [HttpGet("{id}")]
        public async Task<ActionResult<PageCostM>> GetPageCost(int id)
        {
            var pageCost = await _printSystemService.GetConversion(id);
            if (pageCost == null)
            {
                return NotFound();
            }
            return Ok(pageCost);
        }

        // GET: api/PageCosts/5/quantity
        [HttpGet("{id}/{quantity}")]
        public async Task<ActionResult<PageCostM>> GetPageCost(int id, int quantity)
        {
            var pageCost = await _printSystemService.GetConversion(id);
            if (pageCost == null)
            {
                return NotFound();
            }
            pageCost.CostOnePage = _printSystemService.CalculateQuotaInNbA4(pageCost.CostOnePage, quantity);
            return Ok(pageCost);
        }

        // GET: api/PageCosts/byformat/{format}
        [HttpGet("byformat/{format}")]
        public async Task<ActionResult<PageCostM>> GetPageCostByFormat(string format)
        {
            var pageCost = await _printSystemService.GetConversion(format);
            if (pageCost == null)
            {
                return NotFound();
            }
            return Ok(pageCost);
        }

        // POST: api/PageCosts
        [HttpPost]
        public async Task<ActionResult<PageCostM>> PostPageCost(PageCostM pageCostM)
        {
            if (!_printSystemService.CheckPositiveQuotas(pageCostM.CostOnePage))
            {
                return BadRequest();
            }

            if (await _context.PageCosts.AnyAsync(e => e.PageFormat == pageCostM.PageFormat))
            {
                return BadRequest();
            }

            var pageCostDAL = PageCostMapper.ToDAL(pageCostM);
            _context.PageCosts.Add(pageCostDAL);
            await _context.SaveChangesAsync();

            var createdPageCost = PageCostMapper.ToDTO(pageCostDAL);
            return CreatedAtAction(nameof(GetPageCosts), new { id = createdPageCost.ID }, createdPageCost);
        }

        // PUT: api/PageCosts/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutPageCost(int id, PageCostM pageCostM)
        {
            if (pageCostM.CostOnePage < 0)
            {
                return BadRequest();
            }

            var existingPageCost = await _context.PageCosts.FindAsync(id);
            if (existingPageCost == null)
            {
                return NotFound();
            }

            if (pageCostM.PageFormat != existingPageCost.PageFormat &&
                await _context.PageCosts.AnyAsync(e => e.PageFormat == pageCostM.PageFormat))
            {
                return BadRequest();
            }

            existingPageCost.CostOnePage = pageCostM.CostOnePage;
            existingPageCost.PageFormat = pageCostM.PageFormat;
            _context.Entry(existingPageCost).State = EntityState.Modified;
            await _context.SaveChangesAsync();

            var updatedPageCost = PageCostMapper.ToDTO(existingPageCost);
            return Ok(updatedPageCost);
        }

        // DELETE: api/PageCosts/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeletePageCost(int id)
        {
            var pageCost = await _context.PageCosts.FindAsync(id);
            if (pageCost == null)
            {
                return NotFound();
            }

            _context.PageCosts.Remove(pageCost);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
