﻿using DTO;
using Microsoft.AspNetCore.Mvc;
using BLL.Services;

namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly IUserSAP_Service _userSAPService;

        public UsersController(IUserSAP_Service userSAPService)
        {
            _userSAPService = userSAPService;
        }

        // GET with cardID
        [HttpGet("{cardID}")]
        public async Task<ActionResult<UserM>> GetUserByCardID(int cardID)
        {
            if(!_userSAPService.ValidUserInSAP(cardID))
            {
                return NotFound();
            }
            var user = await _userSAPService.GetUserByCardID(cardID);
            return Ok(user);
        }
    }
}
