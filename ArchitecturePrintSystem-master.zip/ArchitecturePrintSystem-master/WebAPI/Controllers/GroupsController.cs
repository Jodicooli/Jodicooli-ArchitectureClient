﻿using DTO;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DAL;
using BLL.Mapper;

namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GroupsController : ControllerBase
    {
        private readonly Context _context;

        public GroupsController(Context context)
        {
            _context = context;
        }

        // GET: api/Groups
        [HttpGet]
        public async Task<ActionResult<IEnumerable<GroupM>>> GetGroups()
        {
            var groups = await _context.Groups.ToListAsync();
            var ListOfGroupsM = groups.Select(group => GroupMapper.ToDTO(group)).ToList();
            return Ok(ListOfGroupsM);
        }

        // GET: api/Groups/5
        [HttpGet("{id}")]
        public async Task<ActionResult<GroupM>> GetGroup(int id)
        {
            var group = await _context.Groups.FindAsync(id);
            if (group == null)
            {
                return NotFound();
            }
            return Ok(GroupMapper.ToDTO(group));
        }


    }
}
