﻿using DTO;
using Microsoft.AspNetCore.Mvc;
using BLL.Services;
using BLL.Mapper;
using DAL;
using Microsoft.EntityFrameworkCore;
using DAL.Models;

[Route("api/[controller]")]
[ApiController]
public class AccountsController : ControllerBase
{
    private readonly IAccount_Service _accountService;
    private readonly IPrintSystem_Service _printSystemService;
    private readonly Context _context;

    public AccountsController(IAccount_Service accountService, IPrintSystem_Service printSystemService, Context context)
    {
        _accountService = accountService;
        _printSystemService = printSystemService;
        _context = context;
    }

    // GET: api/Accounts
    [HttpGet]
    public async Task<ActionResult<IEnumerable<AccountM>>> GetAccounts()
    {
        var accounts = await _context.Accounts.OrderBy(a => a.GroupId).ToListAsync();
        var accountsM = accounts.Select(account => AccountMapper.ToDTO(account)).ToList();
        foreach (var accountM in accountsM)
        {
            var group = await _context.Groups.FindAsync(accountM.GroupId);
            if (group != null)
            {
                accountM.GroupName = group.Name;
                accountM.GroupDescription = group.Description;
            }
        }
        return Ok(accountsM);
    }

    // GET: api/Accounts/5
    [HttpGet("{id}")]
    public async Task<ActionResult<AccountM>> GetAccount(int id)
    {
        if (!_accountService.ValidUID(id))
        {
            return NotFound();
        }
        var account = await _context.Accounts.FindAsync(id);

        var accountM = AccountMapper.ToDTO(account);
        var group = await _context.Groups.FindAsync(accountM.GroupId);
        if (group != null)
        {
            accountM.GroupName = group.Name;
            accountM.GroupDescription = group.Description;
        }
        return Ok(accountM);
    }

    // GET: api/Accounts/byusername/{username}
    [HttpGet("byusername/{username}")]
    public async Task<ActionResult<AccountM>> GetAccountByUsername(string username)
    {
        if (!_accountService.ValidUsername(username))
        {
            return NotFound();
        }
        var account = await _context.Accounts.FirstOrDefaultAsync(a => a.Username == username);
        var accountM = AccountMapper.ToDTO(account);
        var group = await _context.Groups.FindAsync(accountM.GroupId);
        if (group != null)
        {
            accountM.GroupName = group.Name;
            accountM.GroupDescription = group.Description;
        }
        return Ok(accountM);
    }

    // POST: api/Accounts
    [HttpPost]
    public async Task<ActionResult<AccountM>> PostAccount(AccountM accountM)
    {
        if (!_printSystemService.CheckPositiveQuotas(accountM.Balance))
        {
            return BadRequest();
        }

        if (_accountService.ValidUsername(accountM.Username))
        {
            return NotFound();
        }

        var account = AccountMapper.ToDAL(accountM);
        _context.Accounts.Add(account);
        await _context.SaveChangesAsync();
        account.History = new List<float>();
        if(account.Balance != 0)
        {
            account.History.Add(account.Balance);
        }
        await _context.SaveChangesAsync();

        var user = new User
        {
            CardID = account.UID * 333,
            Username = account.Username,
        };

        _context.Users.Add(user);
        await _context.SaveChangesAsync();

        var createdAccount = AccountMapper.ToDTO(account);
        return CreatedAtAction(nameof(GetAccount), new { id = createdAccount.UID }, createdAccount);

    }

    // PUT: api/Accounts/5
    [HttpPut("{id}")]
    public async Task<IActionResult> PutAccount(AccountM accountM)
    {
        var account = await _context.Accounts.FindAsync(accountM.UID);
        account.Lastname = accountM.Lastname;
        account.Surname = accountM.Surname;
        account.Username = accountM.Username;
        account.Balance = accountM.Balance;
        account.GroupId = accountM.GroupId;

        _context.Entry(account).State = EntityState.Modified;
        await _context.SaveChangesAsync();

        var updatedAccount = AccountMapper.ToDTO(account);
        return Ok(updatedAccount);
    }

    // DELETE: api/Accounts/5
    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteAccount(int id)
    {
        var account = await _context.Accounts.FindAsync(id);
        if (account == null)
        {
            return NotFound();
        }

        _context.Accounts.Remove(account);
        await _context.SaveChangesAsync();

        var user = await _context.Users.FirstOrDefaultAsync(u => u.UID == id);
        if (user != null)
        {
            _context.Users.Remove(user);
            await _context.SaveChangesAsync();
        }

        return Ok();
    }

    // PUT: api/Accounts/5/AddAmount
    [HttpPut("{id}/AddAmount")]
    public async Task<ActionResult<AccountM>> AddAmount([FromBody] AdjustBalanceM adjustBalanceM)
    {
        if (!_printSystemService.CheckPositiveQuotas(adjustBalanceM.Amount))
        {
            return BadRequest();
        }
        var account = await _accountService.AddAmount(adjustBalanceM);
        return Ok(account);
    }

    // PUT: api/Accounts/5/Print
    [HttpPost("{id}/Print")]
    public async Task<ActionResult<AccountM>> Print([FromBody] PrintM printM)
    {
        var account = await _printSystemService.AdjustBalance(printM);
        if (account == null)
        {
            return BadRequest();
        }
        return Ok(account);
    }

    // PUT: api/Accounts/5/AddAmountByGID
    [HttpPut("{id}/AddAmountByGID")]
    public async Task<ActionResult<AccountM>> AddAmountByGID([FromBody] AdjustBalanceM adjustBalanceM)
    {
        if (!_printSystemService.CheckPositiveQuotas(adjustBalanceM.Amount))
        {
            return BadRequest();
        }
        var adjustBalance = await _accountService.AddAmountByGID(adjustBalanceM);
        return Ok(adjustBalance);
    }
}
