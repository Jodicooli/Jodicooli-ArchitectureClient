using BLL.Services;
using DAL;
using DAL.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Query.Internal;
using System.Reflection.Emit;



var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddScoped<IAccount_Service, Account_Service>();
builder.Services.AddScoped<IPrintSystem_Service, PrintSystem_Service>();
builder.Services.AddScoped<IUserSAP_Service, UserSAP_Service>();

//builder.Services.AddSingleton<IAccount_Service, Account_Service>();
//builder.Services.AddSingleton<IPrintSystem_Service, PrintSystem_Service>();

builder.Services.AddControllers();

builder.Services.AddDbContext<Context>(options =>
    {
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection"));
    }
);

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

using (var scope = app.Services.CreateScope())
{
    var services = scope.ServiceProvider;
    var context = services.GetRequiredService<Context>();
    context.Database.Migrate();
    seed(context);
}

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();


void seed(Context context)
{
    // V�rifier si des donn�es existent d�j� pour �viter des doublons
    if (!context.Groups.Any())
    {
        context.Groups.AddRange(
            new Group { GID = 1, Name = "604_F", Description = "Business IT 4. Semester french" },
            new Group { GID = 2, Name = "604_D", Description = "Business IT 4. Semester german" },
            new Group { GID = 3, Name = "Teacher", Description = "Teachers from the HES-SO" }
        );
    }

    if (!context.Accounts.Any())
    {
        context.Accounts.AddRange(
            new Account { UID = 1, Lastname = "Ramirez", Username = "ral", Surname = "Luana", Balance = 50, GroupId = 1, History = new List<float> { 50 } },
            new Account { UID = 2, Lastname = "Dias", Username = "dia", Surname = "Adriano", Balance = 50, GroupId = 1, History = new List<float> { 50 } },
            new Account { UID = 3, Lastname = "Gloor", Username = "glg", Surname = "Gian-Luca", Balance = 50, GroupId = 1, History = new List<float> { 50 } },
            new Account { UID = 4, Lastname = "Summermatter", Username = "suj", Surname = "Johanna", Balance = 50, GroupId = 2, History = new List<float> { 50 } },
            new Account { UID = 5, Lastname = "Lotscher", Username = "lon", Surname = "Nadja", Balance = 50, GroupId = 2, History = new List<float> { 50 } },
            new Account { UID = 6, Lastname = "Januzi", Username = "jat", Surname = "Tringa", Balance = 50, GroupId = 2, History = new List<float> { 50 } },
            new Account { UID = 7, Lastname = "Wannier", Username = "wad", Surname = "David", Balance = 100, GroupId = 3, History = new List<float> { 100 } },
            new Account { UID = 8, Lastname = "Duc", Username = "dua", Surname = "Alain", Balance = 100, GroupId = 3, History = new List<float> { 100 } },
            new Account { UID = 9, Lastname = "Widmer", Username = "wia", Surname = "Antoine", Balance = 100, GroupId = 3, History = new List<float> { 100 } },
            new Account { UID = 10, Lastname = "Schumann", Username = "scr", Surname = "Rene", Balance = 100, GroupId = 3, History = new List<float> { 100 } }
        );
    }

    if (!context.Users.Any())
    {
        context.Users.AddRange(
            new User { CardID = 1 * 333, UID = 1, Username = "ral" },
            new User { CardID = 2 * 333, UID = 2, Username = "dia" },
            new User { CardID = 3 * 333, UID = 3, Username = "glg" },
            new User { CardID = 4 * 333, UID = 4, Username = "suj" },
            new User { CardID = 5 * 333, UID = 5, Username = "lon" },
            new User { CardID = 6 * 333, UID = 6, Username = "jat" },
            new User { CardID = 7 * 333, UID = 7, Username = "wad" },
            new User { CardID = 8 * 333, UID = 8, Username = "dua" },
            new User { CardID = 9 * 333, UID = 9, Username = "wia" },
            new User { CardID = 10 * 333, UID = 10, Username = "scr" }
        );
    }

    context.SaveChanges();
}