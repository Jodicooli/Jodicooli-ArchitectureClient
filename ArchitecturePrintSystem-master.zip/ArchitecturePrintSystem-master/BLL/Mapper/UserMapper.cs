﻿using DAL.Models;
using DTO;

namespace BLL.Mapper
{
    public class UserMapper
    {
        public static UserM ToDTO(User user)
        {
            return new UserM
            {
                CardID = user.CardID,
                UID = user.UID,
                Username = user.Username
            };
        }

        public static User ToDAL(UserM userM)
        {
            return new User
            {
                CardID = userM.CardID, 
                UID = userM.UID,
                Username = userM.Username
            };
        }
    }
}
