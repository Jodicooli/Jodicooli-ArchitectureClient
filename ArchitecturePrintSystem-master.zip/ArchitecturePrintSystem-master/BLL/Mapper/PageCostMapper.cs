﻿using DAL.Models;
using DTO;

namespace BLL.Mapper
{
    public class PageCostMapper
    {
        public static PageCostM ToDTO(PageCost pageCost)
        {
            return new PageCostM
            {
                ID = pageCost.ID,
                CostOnePage = pageCost.CostOnePage,
                PageFormat = pageCost.PageFormat
            };
        }

        public static PageCost ToDAL(PageCostM pageCostM)
        {
            return new PageCost
            {
                ID = pageCostM.ID,
                CostOnePage = pageCostM.CostOnePage,
                PageFormat = pageCostM.PageFormat
            };
        }
    }
}
