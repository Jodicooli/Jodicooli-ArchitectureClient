﻿using DAL.Models;
using DTO;

namespace BLL.Mapper
{
    public class GroupMapper
    {
        public static GroupM ToDTO(Group group)
        {
            return new GroupM
            {
                GID = group.GID,
                Name = group.Name,
                Description = group.Description
            };
        }

        public static Group ToDAL(GroupM groupM)
        {
            return new Group
            {
                GID = groupM.GID,
                Name = groupM.Name,
                Description = groupM.Description
            };
        }
    }
}
