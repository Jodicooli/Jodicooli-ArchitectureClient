﻿using DAL.Models;
using DTO;

namespace BLL.Mapper
{
    public class AccountMapper
    {
        public static AccountM ToDTO(Account account) { 
            return new AccountM
            {
                UID = account.UID,
                Lastname = account.Lastname,
                Surname = account.Surname,
                Username = account.Username,
                Balance = account.Balance,
                History = account.History,
                GroupId = account.GroupId
            };
        }

        public static Account ToDAL(AccountM accountM)
        {
            return new Account
            {
                UID = accountM.UID, 
                Lastname = accountM.Lastname,
                Surname = accountM.Surname,
                Username = accountM.Username,
                Balance = accountM.Balance,
                History = accountM.History,
                GroupId = accountM.GroupId
            };
        }
    }
}
