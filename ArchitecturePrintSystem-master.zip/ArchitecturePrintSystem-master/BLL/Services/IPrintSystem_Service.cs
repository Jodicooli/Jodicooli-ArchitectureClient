﻿using DTO;

namespace BLL.Services
{
    public interface IPrintSystem_Service
    {
        Boolean CheckPositiveQuotas(float quota);
        float CalculateQuotaInNbA4(float costOnePage, int quantity);
        Task<AccountM> AdjustBalance(PrintM printM);
        Task<IEnumerable<PageCostM>> GetConversion();
        Task<PageCostM> GetConversion(int id);
        Task<PageCostM> GetConversion(string format);
     

    }

}
