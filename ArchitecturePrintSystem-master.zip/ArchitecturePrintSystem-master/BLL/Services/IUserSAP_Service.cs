﻿using DTO;

namespace BLL.Services
{
    public interface IUserSAP_Service
    {
        Task<UserM> GetUserByCardID(int cardID);
        Boolean ValidUserInSAP(int UID);
    }

}
