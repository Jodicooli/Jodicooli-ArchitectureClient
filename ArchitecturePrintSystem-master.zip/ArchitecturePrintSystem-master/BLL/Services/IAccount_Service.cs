﻿using DTO;

namespace BLL.Services
{
    public interface IAccount_Service
    {
        Task<AccountM> AddAmount(AdjustBalanceM adjustBalanceM);
        Boolean ValidUID(int UID);
        Boolean ValidUsername(string username);
        Task<AdjustBalanceM> AddAmountByGID(AdjustBalanceM adjustBalanceM);
    }

}
