﻿using DAL;
using DTO;
using Microsoft.EntityFrameworkCore;
using BLL.Mapper;


namespace BLL.Services
{
    public class PrintSystem_Service : IPrintSystem_Service
    {
        private readonly Context _context;

        public PrintSystem_Service(Context context)
        {
            _context = context;
        }

        // Check if the quota is positive
        public Boolean CheckPositiveQuotas(float quota)
        {
            if (quota < 0)
            {
                return false;
            }
            return true;
        }

        // Calculate the cost of the print
        public float CalculateQuotaInNbA4(float costOnePage, int quantity)
        {
            return (float)Math.Round(costOnePage * quantity, 2);
        }

        // print some pages
        public async Task<AccountM> AdjustBalance(PrintM printM)
        {
            var account = await _context.Accounts.FindAsync(printM.UID);
            if (account == null)
            {
                return null;
            }

            var pageCost = await _context.PageCosts.FindAsync(printM.Id);
            if (pageCost == null)
            {
                return null;
            }

            float cost = CalculateQuotaInNbA4(pageCost.CostOnePage, printM.Quantity);

            if (account.Balance < cost)
            {
                return null;
            }
            //AdjustBalance(account, cost);
            account.Balance = (float)Math.Round(account.Balance - cost, 2);
            account.History.Add(-cost);
            await _context.SaveChangesAsync();

            return AccountMapper.ToDTO(account);
        }

        // Get conversion rate by id
        public async Task<PageCostM> GetConversion(int id)
        {
            var pageCost = await _context.PageCosts.FindAsync(id);
            return pageCost == null ? null : PageCostMapper.ToDTO(pageCost);
        }

        // Get conversion rate by format
        public async Task<PageCostM> GetConversion(string format)
        {
            var pageCost = await _context.PageCosts.FirstOrDefaultAsync(e => e.PageFormat == format);
            return pageCost == null ? null : PageCostMapper.ToDTO(pageCost);
        }

        // Get all conversion rates
        public async Task<IEnumerable<PageCostM>> GetConversion()
        {
            //get all order by price
            var pageCosts = await _context.PageCosts.OrderBy(e => e.CostOnePage).ToListAsync();
            var ListOfPageCostsM = pageCosts.Select(pageCost => PageCostMapper.ToDTO(pageCost)).ToList();
            return ListOfPageCostsM;
        }


    }
}