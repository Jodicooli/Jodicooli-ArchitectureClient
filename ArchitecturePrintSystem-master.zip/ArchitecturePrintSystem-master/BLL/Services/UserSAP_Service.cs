﻿using DAL;
using DTO;
using Microsoft.EntityFrameworkCore;
using BLL.Mapper;

namespace BLL.Services
{
    public class UserSAP_Service : IUserSAP_Service
    {
        private readonly Context _context;

        public UserSAP_Service(Context context)
        {
            _context = context;
        }

        // Get the user by cardID
        public async Task<UserM> GetUserByCardID(int cardID)
        {
            var user = await _context.Users.FirstOrDefaultAsync(u => u.CardID == cardID);
            return user == null ? null : UserMapper.ToDTO(user);
        }

        // Check if the user is valid in SAP
        public Boolean ValidUserInSAP(int cardID)
        {
            if (_context.Users.Any(u => u.CardID == cardID))
            {
                return true;
            }
            return false;
        }

    }

}
