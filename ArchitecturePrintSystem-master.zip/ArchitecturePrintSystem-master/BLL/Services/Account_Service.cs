﻿using BLL.Mapper;
using DAL;
using DTO;
using Microsoft.EntityFrameworkCore;


namespace BLL.Services
{
    public class Account_Service : IAccount_Service
    {
        private readonly Context _context;

        public Account_Service(Context context)
        {
            _context = context;
        }

        // check if UID is valid
        public Boolean ValidUID(int UID)
        {
            return _context.Accounts.Any(a => a.UID == UID);
        }

        // check if username is valid
        public Boolean ValidUsername(string username)
        {
            return _context.Accounts.Any(a => a.Username == username);
        }
        

        // add amount to account
        public async Task<AccountM> AddAmount(AdjustBalanceM adjustBalanceM)
        {
            var account = await _context.Accounts.FindAsync(adjustBalanceM.UID);
            if (account == null)
            {
                return null;
            }

            account.Balance = (float)Math.Round(account.Balance + adjustBalanceM.Amount, 2);
            account.History.Add(adjustBalanceM.Amount);
            await _context.SaveChangesAsync();

            return AccountMapper.ToDTO(account);
        }

        // add amount to account by GID
        public async Task<AdjustBalanceM> AddAmountByGID(AdjustBalanceM adjustBalanceM)
        {
            var accounts = await _context.Accounts.Where(a => a.GroupId == adjustBalanceM.SelectedGroupId).ToListAsync();
            if (accounts.Count == 0)
            {
                return null;
            }
            foreach (var account in accounts)
            {
                account.Balance = (float)Math.Round(account.Balance + adjustBalanceM.Amount, 2);
                account.History.Add(adjustBalanceM.Amount);
            }
            await _context.SaveChangesAsync();
            return adjustBalanceM;
        }
    }
}