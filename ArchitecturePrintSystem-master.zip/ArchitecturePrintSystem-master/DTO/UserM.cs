﻿namespace DTO
{
    public class UserM
    {
        public int CardID { get; set; }
        public int UID { get; set; }
        public string Username { get; set; }
    }
}
