﻿using System.ComponentModel.DataAnnotations;

namespace DTO
{
    public class AccountM
    {
        public int UID { get; set; }
        public string Lastname { get; set; }
        public string Surname { get; set; }
        public string Username { get; set; }
        [Range(0, Double.MaxValue, ErrorMessage = "Balance must be positive")]
        public float Balance { get; set; }
        public List<float>? History { get; set; }
        public int GroupId { get; set; }
        public string? GroupName { get; set; }
        public string? GroupDescription { get; set; }
    }

}
