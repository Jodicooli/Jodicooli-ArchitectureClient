﻿using System.ComponentModel.DataAnnotations;

namespace DTO
{
    public class AdjustBalanceM
    {
        public string? Username { get; set; }
        public int? UID { get; set; }
        public int? SelectedGroupId { get; set; }
        public string? GroupName { get; set; }
        [Range(1, Double.MaxValue, ErrorMessage = "Balance must be positive")]
        public float Amount { get; set; }
        public float CurrentBalance { get; set; }
        public string SelectedIdentifierType { get; set; } = "Username"; 

    }
}
