﻿namespace DTO
{
    public class GroupM
    {
        public int GID { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
    }
}
