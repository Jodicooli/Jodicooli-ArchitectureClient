﻿using System.ComponentModel.DataAnnotations;

namespace DTO
{
    public class PrintM
    {
        public int? UID { get; set; }
        [Range(1, Double.MaxValue, ErrorMessage = "CardID must be a positive number")]
        public int? CardID { get; set; }
        public int? Id { get; set; }
        public string? Username { get; set; }
        public string? PageFormat { get; set; }
        [Range(1, Double.MaxValue, ErrorMessage = "Quantity must be positive")]
        public int Quantity { get; set; }
        public float? Price { get; set; }
        public string SelectedIdentifierType { get; set; } = "CardID"; 

    }
}
