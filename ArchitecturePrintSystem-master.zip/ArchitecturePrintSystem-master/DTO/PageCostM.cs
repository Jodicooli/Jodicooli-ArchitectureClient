﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace DTO
{
    public class PageCostM
    {
        public int ID { get; set; }
        [Range(0.01, Double.MaxValue, ErrorMessage = "Cost must be positive")]
        public float CostOnePage { get; set; }
        public string PageFormat { get; set; }
        public int? AmountOfPages { get; set; }
    }
}
